#!/system/bin/sh
# FaceUnlock - Kurulum sonrası tarayıcıyı çalıştır

/data/adb/modules/faceunlock/system/bin/faceunlock-scanner >/dev/null 2>&1 &