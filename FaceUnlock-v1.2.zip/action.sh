#!/system/bin/sh
# FaceUnlock - Eylem butonu v1.2

MODUL_DIZINI="/data/adb/modules/faceunlock"
WEBROOT="$MODUL_DIZINI/webroot"
AYAR_DIZINI="/data/local/tmp/faceunlock"
AYAR_DOSYASI="$AYAR_DIZINI/config.ini"

mkdir -p $AYAR_DIZINI

# Varsayılan ayarlar
if [ ! -f "$AYAR_DOSYASI" ]; then
    cat > $AYAR_DOSYASI << EOF
# FaceUnlock Ayarları v1.2
P_ARLIK_SEVIYESI=150
BEKLEME_SURESI=2
SENSOR_HASSASIYETI=5
PIL_TASARRUFU_MODUNDA_KAPALI=1
AKTIF_SAAT_BASLANGIC=22:00
AKTIF_SAAT_BITIS=07:00
EOF
fi

# Arayüzü aç
am start -a android.intent.action.VIEW -d "file://$WEBROOT/index.html" -t "text/html"