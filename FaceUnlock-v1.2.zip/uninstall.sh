#!/system/bin/sh
# FaceUnlock - Kaldırma betiği

rm -rf /data/local/tmp/faceunlock
echo "✅ FaceUnlock v1.2 kaldırıldı"