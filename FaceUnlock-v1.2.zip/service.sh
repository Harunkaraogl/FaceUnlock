#!/system/bin/sh
# FaceUnlock - EVRENSEL SERVİS v1.2
# Bulduğu her şeyi kullanır, hiçbir şeyi varsaymaz!

CONFIG="/data/local/tmp/faceunlock/found_config.conf"
LOG="/data/local/tmp/faceunlock/service.log"
TEMP_DIR="/data/local/tmp/faceunlock"

echo "$(date): 🔆 FaceUnlock v1.2 EVRENSEL servis başladı" > $LOG

# ============================================
# KONFİGÜRASYONU YÜKLE
# ============================================
load_config() {
    if [ -f "$CONFIG" ]; then
        BEST_SENSOR=$(grep "BEST_SENSOR=" $CONFIG | cut -d'"' -f2)
        LOCK_METHOD=$(grep "LOCK_METHOD=" $CONFIG | cut -d'"' -f2)
        POWER_METHOD=$(grep "POWER_METHOD=" $CONFIG | cut -d'"' -f2)
        BRIGHTNESS_SETTING=$(grep "BRIGHTNESS_SETTING=" $CONFIG | cut -d'"' -f2)
        
        echo "$(date): 📖 Konfigürasyon yüklendi" >> $LOG
        echo "  Sensor: $BEST_SENSOR" >> $LOG
        echo "  Kilit: $LOCK_METHOD" >> $LOG
        echo "  Pil: $POWER_METHOD" >> $LOG
    else
        echo "$(date): ⚠️ Konfigürasyon yok, tarayıcı çalıştırılıyor..." >> $LOG
        /data/adb/modules/faceunlock/system/bin/faceunlock-scanner >/dev/null 2>&1
        load_config
    fi
}

# ============================================
# SENSÖR OKU (BULDUĞU DOSYAYI KULLANIR)
# ============================================
read_light() {
    # 1. Önce bulunan en iyi sensörü dene
    if [ -n "$BEST_SENSOR" ] && [ -f "$BEST_SENSOR" ]; then
        value=$(cat "$BEST_SENSOR" 2>/dev/null | head -n1 | tr -cd '0-9')
        if [ -n "$value" ]; then
            echo "$value"
            return
        fi
    fi
    
    # 2. Hiçbir şey bulunamadıysa, anlık tarama yap
    for file in $(find /sys -type f -name "*light*" -o -name "*als*" 2>/dev/null | head -10); do
        val=$(cat $file 2>/dev/null | head -n1 | tr -cd '0-9')
        if [ -n "$val" ] && [ "$val" -gt 0 ] 2>/dev/null; then
            echo "$val"
            return
        fi
    done
    
    # 3. Varsayılan değer
    echo "100"
}

# ============================================
# KİLİT KONTROLÜ (BULDUĞU KELİMEYİ KULLANIR)
# ============================================
is_locked() {
    local window_dump=$(dumpsys window)
    
    # Bulunan kelime varsa onu kullan
    if [ -n "$LOCK_METHOD" ]; then
        echo "$window_dump" | grep -q "$LOCK_METHOD" && return 0
    fi
    
    # Yoksa tüm olası kelimeleri dene
    for word in lockscreen keyguard dreaming showingLockscreen mShowingLockscreen; do
        echo "$window_dump" | grep -q "$word" && return 0
    done
    
    return 1
}

# ============================================
# PİL TASARRUFU KONTROLÜ
# ============================================
is_power_saving() {
    local power_dump=$(dumpsys power)
    
    if [ -n "$POWER_METHOD" ]; then
        echo "$power_dump" | grep -q "$POWER_METHOD" && return 0
    fi
    
    for word in lowPowerMode powerSave batterySaver mLowPowerMode; do
        echo "$power_dump" | grep -q "$word" && return 0
    done
    
    return 1
}

# ============================================
# PARLAKLIK AYARLA
# ============================================
set_brightness() {
    local value=$1
    if [ -n "$BRIGHTNESS_SETTING" ]; then
        settings put system $BRIGHTNESS_SETTING $value
    else
        settings put system screen_brightness $value
    fi
}

get_brightness() {
    if [ -n "$BRIGHTNESS_SETTING" ]; then
        settings get system $BRIGHTNESS_SETTING
    else
        settings get system screen_brightness
    fi
}

# ============================================
# ANA DÖNGÜ
# ============================================
load_config
echo "$(date): 🚀 Ana döngü başlıyor" >> $LOG

SON_PARLAKLIK=""
SAYAC=0

while true; do
    SAYAC=$((SAYAC + 1))
    
    # Her 10 döngüde bir log
    if [ $((SAYAC % 10)) -eq 0 ]; then
        echo "$(date): 💓 Servis aktif" >> $LOG
    fi
    
    # Pil tasarrufu kontrolü
    if is_power_saving; then
        sleep 5
        continue
    fi
    
    # Kilit ekranı kontrolü
    if is_locked; then
        # Işık oku
        light=$(read_light)
        
        # Karanlık mı? (20 eşik değeri)
        if [ "$light" -lt 20 ] 2>/dev/null; then
            # Karanlık!
            if [ -z "$SON_PARLAKLIK" ]; then
                SON_PARLAKLIK=$(get_brightness)
                set_brightness 255
                echo "$(date): 🔆 KARANLIK! Işık:$light" >> $LOG
            fi
            sleep 2
        else
            # Aydınlık
            if [ -n "$SON_PARLAKLIK" ]; then
                set_brightness $SON_PARLAKLIK
                SON_PARLAKLIK=""
                echo "$(date): ☀️ Aydınlık, normale döndü" >> $LOG
            fi
        fi
    else
        # Kilit açıldı
        if [ -n "$SON_PARLAKLIK" ]; then
            set_brightness $SON_PARLAKLIK
            SON_PARLAKLIK=""
            echo "$(date): 🔓 Kilit açıldı" >> $LOG
        fi
    fi
    
    sleep 1
done