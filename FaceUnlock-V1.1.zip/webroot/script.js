// Sayfa yüklendiğinde ayarları API'den al
document.addEventListener('DOMContentLoaded', function() {
    fetchAyarlar();
});

// Ayarları sunucudan getir
function fetchAyarlar() {
    fetch('/cgi-bin/save.sh')
        .then(response => response.json())
        .then(data => {
            document.getElementById('parlaklik').value = data.parlaklik_seviyesi || 150;
            document.getElementById('bekleme').value = data.bekleme_suresi || 2;
            // ... diğer alanları doldur
        })
        .catch(error => console.error('Hata:', error));
}

// Kaydet butonuna tıklandığında
document.getElementById('kaydetBtn').addEventListener('click', function() {
    // Değerleri topla
    const params = new URLSearchParams({
        parlaklik: document.getElementById('parlaklik').value,
        bekleme: document.getElementById('bekleme').value,
        // ... diğer parametreler
    });
    
    // API'ye POST isteği gönder
    fetch('/cgi-bin/save.sh?' + params.toString())
        .then(response => response.json())
        .then(data => {
            document.getElementById('durum').innerText = '✅ ' + data.message;
            setTimeout(() => document.getElementById('durum').innerText = '', 3000);
        })
        .catch(error => {
            document.getElementById('durum').innerText = '❌ Hata oluştu!';
        });
});