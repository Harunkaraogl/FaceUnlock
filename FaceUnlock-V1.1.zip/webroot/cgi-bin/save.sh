#!/system/bin/sh
# Bu betik, web sunucusu tarafından çağrılır (POST/GET istekleri için)

echo "Content-type: application/json"
echo ""

AYAR_DIZINI="/data/local/tmp/karanlik_yuz_modulu"
AYAR_DOSYASI="$AYAR_DIZINI/config.ini"

# GET parametrelerini oku (query string)
if [ -n "$QUERY_STRING" ]; then
    # Query string'den değerleri ayıkla ve kaydet
    echo "$QUERY_STRING" | tr '&' '\n' | while read param; do
        anahtar=$(echo $param | cut -d'=' -f1)
        deger=$(echo $param | cut -d'=' -f2)
        
        case $anahtar in
            parlaklik) sed -i "s/^P_ARLIK_SEVIYESI=.*/P_ARLIK_SEVIYESI=$deger/" $AYAR_DOSYASI ;;
            bekleme) sed -i "s/^BEKLEME_SURESI=.*/BEKLEME_SURESI=$deger/" $AYAR_DOSYASI ;;
            # ... diğer parametreler
        esac
    done
    
    echo '{"status":"success","message":"Ayarlar kaydedildi"}'
else
    # Ayarları oku ve JSON olarak döndür
    echo '{'
    cat $AYAR_DOSYASI | grep -v '^#' | while read line; do
        anahtar=$(echo $line | cut -d'=' -f1 | tr '[:upper:]' '[:lower:]')
        deger=$(echo $line | cut -d'=' -f2)
        echo "\"$anahtar\":\"$deger\","
    done | sed '$ s/,//'
    echo '}'
fi