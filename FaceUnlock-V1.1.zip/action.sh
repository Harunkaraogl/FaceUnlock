#!/system/bin/sh
# FaceUnlock - Eylem butonu (V1.1)
# KİKYO FLOWER ASH

MODUL_DIZINI="/data/adb/modules/faceunlock"
WEBROOT="$MODUL_DIZINI/webroot"
AYAR_DIZINI="/data/local/tmp/faceunlock"
AYAR_DOSYASI="$AYAR_DIZINI/config.ini"
LOG_DOSYASI="$AYAR_DIZINI/action.log"

# Log başlangıcı
echo "$(date): FaceUnlock V1.1 eylem butonu çalıştı" > $LOG_DOSYASI
echo "MODUL_DIZINI: $MODUL_DIZINI" >> $LOG_DOSYASI

# Ayarlar dizinini oluştur
mkdir -p $AYAR_DIZINI
chmod 755 $AYAR_DIZINI

# Varsayılan ayarları oluştur
if [ ! -f "$AYAR_DOSYASI" ]; then
    cat > $AYAR_DOSYASI <<EOF
# FaceUnlock Ayarları V1.1
P_ARLIK_SEVIYESI=150
BEKLEME_SURESI=2
PIL_TASARRUFU_MODUNDA_KAPALI=1
AKTIF_SAAT_BASLANGIC=22:00
AKTIF_SAAT_BITIS=07:00
SENSOR_HASSASIYETI=5
EOF
    echo "Varsayılan ayarlar oluşturuldu" >> $LOG_DOSYASI
fi

# HTML dosyasını kontrol et
if [ -f "$WEBROOT/index.html" ]; then
    echo "HTML bulundu: $WEBROOT/index.html" >> $LOG_DOSYASI
    
    # İzinleri ayarla
    chmod 644 $WEBROOT/index.html
    chmod 644 $WEBROOT/style.css 2>/dev/null
    chmod 644 $WEBROOT/script.js 2>/dev/null
    
    # MUTLAK YOL ile aç
    HTML_YOLU="file://$WEBROOT/index.html"
    echo "Açılıyor: $HTML_YOLU" >> $LOG_DOSYASI
    
    # Tarayıcıda aç
    am start -a android.intent.action.VIEW -d "$HTML_YOLU" -t "text/html"
else
    echo "HATA: HTML bulunamadı!" >> $LOG_DOSYASI
    echo "Dosyalar:" >> $LOG_DOSYASI
    ls -la $WEBROOT >> $LOG_DOSYASI 2>&1
fi

exit 0