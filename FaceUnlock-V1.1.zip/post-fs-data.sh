#!/system/bin/sh
# Bu betik, /data bölümü bağlandıktan sonra ama sistem tam olarak başlamadan ÇALIŞIR

MODUL_DIZINI=${0%/*}
AYAR_DIZINI="/data/local/tmp/karanlik_yuz_modulu"
VERSION_DOSYASI="$AYAR_DIZINI/version.txt"

# Log dosyası
LOG_DOSYASI="$AYAR_DIZINI/boot.log"
echo "$(date): post-fs-data.sh başladı (V2.0)" >> $LOG_DOSYASI

# 1. Gerekli dizinleri oluştur
mkdir -p $AYAR_DIZINI

# 2. Versiyon kontrolü (güncelleme sonrası eski ayarları koru)
if [ ! -f "$VERSION_DOSYASI" ] || [ "$(cat $VERSION_DOSYASI)" -lt "1" ]; then
    echo "$(date): V1.0'a güncelleme yapılıyor, eski ayarlar korunuyor..." >> $LOG_DOSYASI
    
    # Eski ayar dosyasını yedekle (varsa)
    if [ -f "$AYAR_DIZINI/config.ini" ]; then
        cp "$AYAR_DIZINI/config.ini" "$AYAR_DIZINI/config.ini.yedek"
        echo "$(date): Eski ayarlar yedeklendi" >> $LOG_DOSYASI
    fi
    
    # Yeni versiyon numarasını kaydet
    echo "1" > $VERSION_DOSYASI
fi

# 3. Varsayılan ayar dosyasını kontrol et (V1.0 yeni özellikler eklenmiş olabilir)
if [ ! -f "$AYAR_DIZINI/config.ini" ]; then
    echo "$(date): Varsayılan ayarlar oluşturuluyor (V1.0)..." >> $LOG_DOSYASI
    cat > $AYAR_DIZINI/config.ini <<EOF
# Karanlık Yüz Tanıma Modülü Ayarları - V2.0
P_ARLIK_SEVIYESI=150
BEKLEME_SURESI=2
PIL_TASARRUFU_MODUNDA_KAPALI=1
AKTIF_SAAT_BASLANGIC=22:00
AKTIF_SAAT_BITIS=07:00
SENSOR_HASSASIYETI=5
OTOMATIK_PARLAKLIK_KESINTI=1
# V2.0 YENİ AYARLAR
WEB_SUNUCU_PORTA=8080
GELISMIS_SENSOR_MODE=1
LOG_SEVIYESI=1
EOF
else
    # Eski ayar dosyası varsa, yeni ayarları ekle (eksikse)
    echo "$(date): Eski ayarlar kontrol ediliyor, yeni özellikler ekleniyor..." >> $LOG_DOSYASI
    
    # Yeni ayarları kontrol et ve ekle
    grep -q "WEB_SUNUCU_PORTA" "$AYAR_DIZINI/config.ini" || echo "WEB_SUNUCU_PORTA=8080" >> "$AYAR_DIZINI/config.ini"
    grep -q "GELISMIS_SENSOR_MODE" "$AYAR_DIZINI/config.ini" || echo "GELISMIS_SENSOR_MODE=1" >> "$AYAR_DIZINI/config.ini"
    grep -q "LOG_SEVIYESI" "$AYAR_DIZINI/config.ini" || echo "LOG_SEVIYESI=1" >> "$AYAR_DIZINI/config.ini"
fi

# 4. Sistem özelliklerini kontrol et ve kaydet
echo "$(date): Cihaz bilgileri (V1.0):" >> $LOG_DOSYASI
echo "Model: $(getprop ro.product.model)" >> $LOG_DOSYASI
echo "Android: $(getprop ro.build.version.release)" >> $LOG_DOSYASI
echo "MIUI: $(getprop ro.miui.ui.version.name 2>/dev/null || echo 'Yok')" >> $LOG_DOSYASI
echo "OneUI: $(getprop ro.build.version.oneui 2>/dev/null || echo 'Yok')" >> $LOG_DOSYASI

# 5. Sensör yollarını otomatik algıla (V1.0 özelliği)
SENSOR_YOLU=""
if [ -d "/sys/class/leds/lcd-backlight/device/light" ]; then
    SENSOR_YOLU="/sys/class/leds/lcd-backlight/device/light"
elif [ -f "/sys/devices/virtual/misc/microp/light_sensor" ]; then
    SENSOR_YOLU="/sys/devices/virtual/misc/microp/light_sensor"
elif [ -f "/sys/bus/i2c/devices/2-0038/light_sensor" ]; then
    SENSOR_YOLU="/sys/bus/i2c/devices/2-0038/light_sensor"
fi

if [ -n "$SENSOR_YOLU" ]; then
    echo "SENSOR_YOLU=$SENSOR_YOLU" >> "$AYAR_DIZINI/config.ini"
    echo "$(date): Sensör yolu algılandı: $SENSOR_YOLU" >> $LOG_DOSYASI
else
    echo "$(date): Sensör yolu algılanamadı, varsayılan yöntem kullanılacak" >> $LOG_DOSYASI
fi

# 6. Eski sunucu PID dosyasını temizle
if [ -f "$AYAR_DIZINI/server.pid" ]; then
    ESKI_PID=$(cat $AYAR_DIZINI/server.pid)
    if kill -0 $ESKI_PID 2>/dev/null; then
        echo "$(date): Eski sunucu bulundu (PID: $ESKI_PID), sonlandırılıyor..." >> $LOG_DOSYASI
        kill -9 $ESKI_PID
    fi
    rm -f $AYAR_DIZINI/server.pid
fi

# 7. İzinleri ayarla
chmod 755 $AYAR_DIZINI
chmod 644 $AYAR_DIZINI/config.ini
chmod 644 $AYAR_DIZINI/version.txt 2>/dev/null

echo "$(date): post-fs-data.sh tamamlandı (V1.0)" >> $LOG_DOSYASI
exit 0