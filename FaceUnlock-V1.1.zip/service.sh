#!/system/bin/sh
# FaceUnlock - Ana Servis (V1.1)
# KİKYO FLOWER ASH

MODUL_DIZINI="/data/adb/modules/faceunlock"
AYAR_DIZINI="/data/local/tmp/faceunlock"
AYAR_DOSYASI="$AYAR_DIZINI/config.ini"
LOG_DOSYASI="$AYAR_DIZINI/service.log"

# Log başlangıcı
echo "$(date): FaceUnlock V1.1 servisi başlatıldı" > $LOG_DOSYASI

# Varsayılan ayarlar
P_ARLIK_SEVIYESI=150
BEKLEME_SURESI=2
PIL_TASARRUFU_MODUNDA_KAPALI=1
AKTIF_SAAT_BASLANGIC="22:00"
AKTIF_SAAT_BITIS="07:00"
SENSOR_HASSASIYETI=5

# Ayarları oku
if [ -f "$AYAR_DOSYASI" ]; then
    while IFS='=' read -r key value; do
        case $key in
            "P_ARLIK_SEVIYESI") P_ARLIK_SEVIYESI=$value ;;
            "BEKLEME_SURESI") BEKLEME_SURESI=$value ;;
            "PIL_TASARRUFU_MODUNDA_KAPALI") PIL_TASARRUFU_MODUNDA_KAPALI=$value ;;
            "AKTIF_SAAT_BASLANGIC") AKTIF_SAAT_BASLANGIC=$value ;;
            "AKTIF_SAAT_BITIS") AKTIF_SAAT_BITIS=$value ;;
            "SENSOR_HASSASIYETI") SENSOR_HASSASIYETI=$value ;;
        esac
    done < "$AYAR_DOSYASI"
    echo "Ayarlar yüklendi" >> $LOG_DOSYASI
fi

# Işık sensörünü oku (GELİŞTİRİLMİŞ)
isik_sensorunu_oku() {
    # Bilinen tüm sensör yollarını dene
    for sensor_yolu in \
        "/sys/class/leds/lcd-backlight/device/light" \
        "/sys/devices/virtual/misc/microp/light_sensor" \
        "/sys/bus/i2c/devices/2-0038/light_sensor" \
        "/sys/class/sensors/light_sensor/illuminance" \
        "/sys/devices/platform/soc/ae01000.i2c/i2c-3/3-0040/light_sensor" \
        "/sys/devices/platform/11019000.i2c/i2c-2/2-0038/light_sensor" \
        "/sys/devices/virtual/sensor/light_sensor/light_sensor" \
        "/sys/class/power_supply/battery/light_level"; do
        
        if [ -f "$sensor_yolu" ]; then
            deger=$(cat "$sensor_yolu" 2>/dev/null | head -n1 | tr -cd '0-9')
            if [ -n "$deger" ] && [ "$deger" -gt 0 ] 2>/dev/null; then
                echo "$deger"
                return
            fi
        fi
    done
    
    # Son çare: sensorservice
    deger=$(dumpsys sensorservice 2>/dev/null | grep -i "light" | tail -n1 | grep -o '[0-9]\+' | head -n1)
    echo "${deger:-100}"
}

# Kilit ekranı kontrolü (GELİŞTİRİLMİŞ)
kilit_kontrol() {
    # Birden çok yöntem dene
    dumpsys window | grep -E "mShowingLockscreen|mDreamingLockscreen" | grep -q "true" && return 0
    dumpsys statusbar | grep -q "mCurrentlyShowing=true" && return 0
    dumpsys display | grep -q "mScreenState=OFF" && return 1
    return 1
}

# Pil tasarrufu kontrolü
pil_tasarrufu_kontrol() {
    if [ "$PIL_TASARRUFU_MODUNDA_KAPALI" = "1" ]; then
        dumpsys power | grep -q "mLowPowerMode=true" && return 0
    fi
    return 1
}

# Saat kontrolü
saat_kontrol() {
    SU_AN=$(date +%H:%M)
    
    if [ "$AKTIF_SAAT_BASLANGIC" \< "$AKTIF_SAAT_BITIS" ]; then
        if [ "$SU_AN" \> "$AKTIF_SAAT_BASLANGIC" ] && [ "$SU_AN" \< "$AKTIF_SAAT_BITIS" ]; then
            return 0
        fi
    else
        if [ "$SU_AN" \> "$AKTIF_SAAT_BASLANGIC" ] || [ "$SU_AN" \< "$AKTIF_SAAT_BITIS" ]; then
            return 0
        fi
    fi
    return 1
}

# Ana döngü
SON_PARLAKLIK=""
SAYAC=0

while true; do
    SAYAC=$((SAYAC + 1))
    
    # Her 60 döngüde bir log (pil tasarrufu)
    if [ $((SAYAC % 60)) -eq 0 ]; then
        echo "$(date): Servis aktif" >> $LOG_DOSYASI
    fi
    
    # Pil tasarrufu kontrolü
    if pil_tasarrufu_kontrol; then
        sleep 5
        continue
    fi
    
    # Saat kontrolü
    if ! saat_kontrol; then
        sleep 30
        continue
    fi
    
    # Kilit ekranı kontrolü
    if kilit_kontrol; then
        # Işık seviyesini oku
        ISIK=$(isik_sensorunu_oku)
        
        # Karanlık mı? (hassasiyete göre)
        if [ "$ISIK" -lt $((20 * SENSOR_HASSASIYETI)) ] 2>/dev/null; then
            if [ -z "$SON_PARLAKLIK" ]; then
                # Mevcut parlaklığı kaydet
                SON_PARLAKLIK=$(settings get system screen_brightness)
                # Otomatik parlaklığı geçici olarak kapat
                settings put system screen_brightness_mode 0
                # Parlaklığı artır
                settings put system screen_brightness $P_ARLIK_SEVIYESI
                echo "$(date): KARANLIK! Işık:$ISIK, Parlaklık:$P_ARLIK_SEVIYESI" >> $LOG_DOSYASI
            fi
            sleep $BEKLEME_SURESI
        else
            # Aydınlık veya kilit açıldı
            if [ -n "$SON_PARLAKLIK" ]; then
                settings put system screen_brightness $SON_PARLAKLIK
                settings put system screen_brightness_mode 1
                SON_PARLAKLIK=""
                echo "$(date): Aydınlık, normale döndü" >> $LOG_DOSYASI
            fi
        fi
    fi
    
    sleep 1
done