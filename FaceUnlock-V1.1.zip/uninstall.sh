#!/system/bin/sh
# Bu betik, modül kaldırılırken çalışır (V1.0)

MODUL_DIZINI=${0%/*}
AYAR_DIZINI="/data/local/tmp/karanlik_yuz_modulu"
PID_DOSYASI="$AYAR_DIZINI/server.pid"
LOG_DOSYASI="$AYAR_DIZINI/uninstall.log"

echo "$(date): Karanlık Yüz Tanıma V1.0 kaldırılıyor..." > $LOG_DOSYASI

# 1. Web sunucusunu durdur
if [ -f "$PID_DOSYASI" ]; then
    PID=$(cat $PID_DOSYASI)
    if kill -0 $PID 2>/dev/null; then
        echo "Web sunucusu durduruluyor (PID: $PID)..."
        kill -9 $PID
        echo "$(date): Web sunucusu durduruldu" >> $LOG_DOSYASI
    fi
    rm -f $PID_DOSYASI
fi

# 2. Parlaklığı eski haline getir
SON_PARLAKLIK=$(settings get system screen_brightness)
if [ -n "$SON_PARLAKLIK" ]; then
    settings put system screen_brightness_mode 1
    echo "$(date): Otomatik parlaklık geri getirildi" >> $LOG_DOSYASI
fi

# 3. Çalışan servisi durdur
pkill -f "karanlik_yuz_tanima" 2>/dev/null

# 4. Kullanıcıya sor (ayarlar silinsin mi?)
echo "----------------------------------------"
echo "📱 Karanlık Yüz Tanıma V1.0 Kaldırılıyor"
echo "----------------------------------------"
echo "Kullanıcı ayarları ve log dosyaları silinsin mi?"
echo "[E] Evet (Temiz kaldırma)"
echo "[H] Hayır (Ayarları koru, ileride tekrar yüklersen kullan)"
echo -n "Seçiminiz (E/H) [varsayılan: H]: "
read -t 10 KARAR

if [ "$KARAR" = "E" ] || [ "$KARAR" = "e" ]; then
    rm -rf $AYAR_DIZINI
    echo "✅ Tüm ayarlar ve log dosyaları silindi."
    echo "$(date): Tüm dosyalar silindi" >> $LOG_DOSYASI
else
    echo "ℹ️ Ayarlar korundu. (/data/local/tmp/karanlik_yuz_modulu/)"
    echo "$(date): Ayarlar korundu" >> $LOG_DOSYASI
    # Sadece log dosyasını göster
    if [ -f "$LOG_DOSYASI" ]; then
        echo "📋 Kaldırma logu: $LOG_DOSYASI"
    fi
fi

echo "✅ Karanlık Yüz Tanıma V1.0 başarıyla kaldırıldı!"
echo "Bizi tercih ettiğiniz için teşekkürler! 🙏"

exit 0